#include "pch.h"
#include "Stack.h"
//ջ��˳��洢�ṹ��˳�����
#include<iostream>
#include <string.h>


using namespace std;
SqStack sq;
bool is_match(string str) {

	for (int i = 0; i < str.size(); i++) {
		if (str[i] == '('|| str[i] == '{'||str[i]=='[') sq.push(str[i]);
		if (str[i] == ')' || str[i] == '}'||str[i]==']')sq.pop();

	}
	     
	if (sq.IsEmpty())return true;//�ɹ����

	return false;//��Բ��ɹ�
}
int main() {
	string str;

	while (cin >> str)
	{
		
		if (is_match(str)) {

			cout << "yes"<<endl;

		}

		else cout << "no"<<endl;
		sq.SetEmpty();
	}
	
	return 0;
}

